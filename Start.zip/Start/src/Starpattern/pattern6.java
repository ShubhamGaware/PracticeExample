package Starpattern;

public class pattern6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int r=1;r<=5;r++) //for printing  rows
		{
			for(int c=5;c>=r;c--)//printing colums or spaces
			{
				System.out.print(" ");
			 
			}
			for (int k=1; k<=r;k++) //  for printing star
			{
			System.out.print("*");
			}
		System.out.println();	
		}
		for(int r=1;r<=5;r++) //for printing  rows
		{
			for(int c=1;c<=r;c++)//printing colums or spaces
			{
				System.out.print(" ");
			 
			}
			for (int k=5; k>=r;k--) //  for printing star
			{
			System.out.print("*");
			}
		System.out.println();	
		}

	}

}
