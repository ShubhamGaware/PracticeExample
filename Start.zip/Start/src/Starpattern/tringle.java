package Starpattern;

public class tringle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int r,c;
		for(r=1;r<=5;r++)
		{
			for(c=1;c<=r;c++)
			{
				System.out.print("*");
			 
			}
			System.out.println(" ");
		}
	}

}
