package Starpattern;

public class ABBPat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
				int r,c;
				 char ch='A';
				for(r=1;r<=5;r++)
				{
					for(c=1;c<=r;c++)
					{
						System.out.print(ch);
					 
					}
					System.out.println(" ");
					ch++;
				
		}


	}

}
