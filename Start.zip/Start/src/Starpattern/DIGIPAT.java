package Starpattern;

public class DIGIPAT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int r,c;
		 int ch= 1;
		for(r=1;r<=5;r++)
		{
			for(c=1;c<=r;c++)
			{
				System.out.print(ch++);
			 
			}
			System.out.println(" ");
			ch=1;
			}
	}

}
