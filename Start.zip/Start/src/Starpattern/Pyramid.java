package Starpattern;

public class Pyramid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		int j;
		int k;
		int n=5;
		for (i=1;i<=n;i++)
		{ 
			for(j=1;j<=i;j++)
			{
				System.out.print("* ");
			
			for (k =1;k<=i;k++)
			{
			 System.out.print(" ");	
			}}
			System.out.println(" ");	
		}

	}

}
