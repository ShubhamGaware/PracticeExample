package Starpattern;

public class Rowcolm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int r,c;
		for(r=1;r<=5;r++)
		{
			for(c=1;c<=5;c++)
			{
				System.out.print("*");
			}
			System.out.println(" ");
		}
	}

}
