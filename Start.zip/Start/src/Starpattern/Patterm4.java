package Starpattern;

public class Patterm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int r=1;r<=5;r++) //for printing  rows
		{
			for(int c=5;c>=r;c--)//printing colums or spaces
			{
				System.out.print(" ");
			 
			}
			for (int k=1; k<=r;k++) //  for printing star
			{
			System.out.print("*");
			}
		System.out.println();	
		}

	}

}
