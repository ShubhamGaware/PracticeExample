package ControlStatement;

public class SumofEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int Sum=0;
		for(int i=1;i<=1000;i++)
		{
			if (i%2==0)
			{ Sum=Sum+i;
			
			}
			
		}
		System.out.println(Sum);
		
	}

}
