package ControlStatement;

public class While {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           int x=1;
           while(x<=5)
           {
        	   System.out.println(x);
        	   x++;
           }
	}

}
