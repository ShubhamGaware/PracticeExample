package ControlStatement;

import java.util.Scanner;

public class PowerWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int  b,p;
		System.out.println("enter base no");
		b=sc.nextInt();
		System.out.println("enter power no");
		p=sc.nextInt();
		sc.close();
		int h=1;
		int i=1;
		while(i<=p)
		{
			h=h*b;
			i++;
		}
		System.out.println(h);

	}

}
