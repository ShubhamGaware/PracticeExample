package ControlStatement;

import java.util.Scanner;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int  b,p;
		System.out.println("enter base no");
		b=sc.nextInt();
		System.out.println("enter power no");
		p=sc.nextInt();
		sc.close();
		int h=1;
		int i=1;
		do
		{
			h=h*b;
			i++;
		}while(i<=p);
		System.out.println(h);

	}

}
