package ControlStatement;

public class SumofEvenWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=1;
		int Sum=0;
		while(a<=1000)
		{
			if(a%2==0)
			Sum=Sum+a;
			a++;
		}
		System.out.println(Sum);
	}

}
