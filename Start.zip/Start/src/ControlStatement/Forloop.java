package ControlStatement;

public class Forloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;
		for(a=1;a<=10;a++)
		{
			System.out.println(a*5);
		}

		
	}

}
