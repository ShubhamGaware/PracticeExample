package ControlStatement;

import java.util.Scanner;

public class CountDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		Scanner sc = new Scanner (System.in);
		System.out.println("enter Number");
		int n=sc.nextInt();
		sc.close();
		int c=0; 
		for(;;)
		{
			if(n==0)
				break;
			c++;
			n=n/10;
			
		}
		System.out.println("count->"+c);

	}

}
