package ControlStatement;
import java.util.*;

public class PowerExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int  b,p;
		System.out.println("enter base no");
		b=sc.nextInt();
		System.out.println("enter power no");
		p=sc.nextInt();
		sc.close();
		int h=1;
		for(int i=1;i<=p;i++)
		{
			h=h*b;
			
		}
		System.out.println(h);

	}
	}
