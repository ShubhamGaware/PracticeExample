package ControlStatement;

public class SumofNaturalNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		int Sum=0;
		for(i=1;i<=1000;i++)
		{
			Sum=Sum+i;
	
		}
		System.out.println(Sum);

	}

}
