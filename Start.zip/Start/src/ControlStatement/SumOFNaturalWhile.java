package ControlStatement;

public class SumOFNaturalWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=1;
		int Sum=0;
		while(i<=1000)
		{
			Sum=Sum+i;
			
			i++;
		}
		System.out.println(Sum);
		

	}

}
