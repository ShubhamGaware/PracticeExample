package Demo;

public class Exersise6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a =100;
		System.out.println(a);
		a=a+2;
		System.out.println(a);
		a=a-2;
		System.out.println(a);
		a=a*2;
		System.out.println(a);
	}

}
