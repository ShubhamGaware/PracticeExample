package Demo;

public class Exersise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(100+200);
		System.out.println(1220/10);

	}

}
