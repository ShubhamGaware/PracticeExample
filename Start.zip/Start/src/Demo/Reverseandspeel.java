package Demo;

public class Reverseandspeel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int r=0;
 int n=0;
 int y=11111;
 while(y>0)
 {
	 n=y%10;
	// System.out.println(n); digit
	 r=(r*10)+n;
	 y=y/10;
 }
 // System.out.println(n); reverse no
 
 while(r>0) {
	 
 
	 n=r%10;
	 r=r/10;
     switch(n)
     {
     case 0:
    	System.out.println("Zero");
    	break;
     case 1:
     	System.out.println("One");
     	break;
     case 2:
     	System.out.println("Two");
     	break;
     case 3:
     	System.out.println("Three");
     	break;
     case 4:
     	System.out.println("Four");
     	break;
     case 5:
     	System.out.println("Five");
     	break;
     case 6:
     	System.out.println("Six");
     	break;
     case 7:
     	System.out.println("Seven");
     	break;
     case 8:
     	System.out.println("Eght");
     	break;
     case 9:
     	System.out.println("Nine");
     	
     }
     
	}

}
}