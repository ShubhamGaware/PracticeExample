package Demo;
import java.util.*;

public class Substraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter two no :");
		Scanner sc = new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		sc.close();
		int c=a-b;
		System.out.println(c);
		

	}

}
