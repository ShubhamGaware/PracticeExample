package Demo;

public class GradeSystem {

	public static void main(String[] args) {
		// TODO Auto-generated method 
		int roll_no=1002;
		String Name= "Shubham Gaware";
		int Java=80;
		int CPP =75;
		int C =90;
		int python =88;
		int html= 75;
		int total= Java+CPP+C+python+html;
		double perc=(total*100)/500;
		System.out.println(roll_no);
		System.out.println(Name );
		System.out.println(perc);
        
		if (perc>=90)
		{
			System.out.println(" A++ grade");
		} else if (perc<90 && perc >=80)
		{
			System.out.println("A+ grade");
		}else if (perc>80 && perc >=60)
		{
			System.out.println("A grade");
		}
		else if (perc>60 && perc >=35)
		{
			System.out.println("B grade");
		}
		else {		
			System.out.println("Failed ...!");
		}
		
	}

}
