package Demo;

public class Exsersise8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=12345;
		int num2 =45678;
		System.out.println(num1 + " + " + num2 +" = "  +(num1+num2));
		System.out.println(num1 + " - " + num2 +" = "  +(num1-num2));
		System.out.println(num1 + " * " + num2 +" = "  +(num1*num2));
		System.out.println(num1 + " / " + num2 +" = "  +(num1/num2));
		System.out.println(num1 + " % " + num2 +" = "  +(num1%num2));

	}

}
 