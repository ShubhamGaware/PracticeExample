package Demo;

public class DivisibleFive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a= 10;
		 if (a%5==0)
		 {
			 System.out.println("given no  is divisible 5");
		 }
		 else 
		 {
			 System.out.println("given no is not divisible  by 5");
		 }

	}

}
