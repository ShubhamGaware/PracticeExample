package Demo;

public class emp {

	public static void main(String[] args) {
		double BS =20000;
		double Da;
		double Hra;
		double Tra;
		double Pt;
		double pf;
		Da= (BS*8)/100;
		System.out.println("Da: "+ Da);
		Hra= (BS*15)/100;
		System.out.println("Hra: "+ Hra);
		Tra= (BS*5)/100;
		System.out.println("Tra: "+Tra);
		Pt= (BS*8)/100;
		System.out.println("Pt: "+ Pt);
		pf= (BS*12)/100;
		System.out.println("pf: " +pf);
		double gross_sal= BS+Da+Hra+Tra+Pt+pf;
		System.out.println("Gross salary: "+ gross_sal);
		

	}

}
