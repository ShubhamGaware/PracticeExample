package Demo;

public class StudData {

	public static void main(String[] args) {
		int roll_no=1002;
		String Name= "Shubham Gaware";
		int Java=80;
		int CPP =75;
		int C =60;
		int total= Java+CPP+C;
		double perc=total/3;
		System.out.println(roll_no);
		System.out.println(Name );

		System.out.println(perc);

	}

}
