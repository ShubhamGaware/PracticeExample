package Demo;

public class goodpg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a= 10;
		if ((a%3==0)&&(a%5==0)){
			 System.out.println("Good and NICE...!!");
		 }
		 else if(a%5==0) 
		 {
			 System.out.println("Nice...!!!");
			 
		 }
		 else if (a%3==0) {
			 System.out.println("Good..!");
		 }


	}

}
