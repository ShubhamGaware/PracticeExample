package Demo;

public class arithdt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		short a = 32000;
		short b = 32000;
		int sum, max, mul;
		double div;
		
			sum=a+b;
			max=a-b;
			mul=a*b;
			div=a/b;
			System.out.println(sum);
			System.out.println(max);
			System.out.println(mul);
			System.out.println(div);

	}

}
