package Demo;

public class DivesibleThree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 int a= 10;
	 if (a%3==0)
	 {
		 System.out.println("given no  is divisible 3");
	 }
	 else 
	 {
		 System.out.println("given no is not divisible  by 3");
	 }

	}

}
