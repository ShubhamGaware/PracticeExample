package Demo;

public class ArithmeticDT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte a = 100;
		byte b = 127;
		int sum, max, mul;
		double div;
		
			sum=a+b;
			max=a-b;
			mul=a*b;
			div=a/b;
			System.out.println(sum);
			System.out.println(max);
			System.out.println(mul);
			System.out.println(div);

	}

}
