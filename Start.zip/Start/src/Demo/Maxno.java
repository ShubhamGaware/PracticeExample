package Demo;

public class Maxno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=800;
		int b=400;
		int c=300;
		if(a>b&&a>c)
		{
			System.out.println("A is greater");
		}
		else if(b>a&& b>c)
		{
			System.out.println("B is greater");
			
		}else
		{
			System.out.println("C is greater");
		}
	}

}
