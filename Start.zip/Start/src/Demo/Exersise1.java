package Demo;

public class Exersise1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("java by kiran..!");
		System.out.println("Karve nagar ");
		System.out.println(3);
		System.out.println(3+8);
		System.out.println(3-8);
		System.out.println(3*8);
		System.out.println(18/3);

	}
}
