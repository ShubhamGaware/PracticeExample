package Demo;

public class Exsersie4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte a= 127;
		short b= 32000;
		int c= 400000;
		double d= 20.20;
		char Z='a';
		
		
		 String s="Hello ";
		 System.out.println(a);
		 System.out.println(b);
		 System.out.println(c);
		 System.out.println(d);
		 System.out.println(s);
		 System.out.println(Z);
	}

}
