package Demo;

public class arithmatic {

	public static void main(String[] args) {
		int a = 100;
		int b = 200;
		int sum, max, mul;
		double div;
		
			sum=a+b;
			max=a-b;
			mul=a*b;
			div=a/b;
			System.out.println(sum);
			System.out.println(max);
			System.out.println(mul);
			System.out.println(div);
	}

}
