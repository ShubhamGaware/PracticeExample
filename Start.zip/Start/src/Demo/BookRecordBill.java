package Demo;

public class BookRecordBill {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Book_name1= "Java";
		String Book_name2="CPP";
		String Book_name3="Python";
		int price_for_B1 = 500;
		int price_for_B2= 300;
		int price_for_B3= 400;
		int quant1 = 3;
		int quant2 = 4;
		int quant3 = 5;
	System.out.println("Book_name : " + Book_name1 + "\nprice Of book : "+ price_for_B1 + "\nquantity : " +quant1);
	double total_price1 = price_for_B1 *  quant1;
	System.out.println("Total price of JAVA BOOK " + total_price1 );
	System.out.println("Book_name : " + Book_name2 + "\nprice Of book : "+ price_for_B2 + "\nquantity : " +quant2);
	double total_price2 = price_for_B2 *  quant2;
	System.out.println("Total price of CPP BOOK " + total_price2 );
	System.out.println("Book_name : " + Book_name3 + "\nprice Of book : "+ price_for_B3 + "\nquantity : " +quant3);
	double total_price3 = price_for_B3 *  quant3;
	System.out.println("Total price of Python  BOOK : " + total_price3 );
	
	double Total_Bill=total_price1+total_price2+total_price3;
	System.out.println("\nTotal Bill of All Books  :" + Total_Bill);

	}

}
