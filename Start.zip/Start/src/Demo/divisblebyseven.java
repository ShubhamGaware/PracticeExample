package Demo;

public class divisblebyseven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i=100; i<=200;i++)
		  { if (i%7==0)
			  System.out.println(i);
			  
		  }
	}

}
