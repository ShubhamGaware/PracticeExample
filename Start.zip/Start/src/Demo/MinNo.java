package Demo;

public class MinNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10;
		int b=500;
		int c=300;
		if(a<b&&a<c)
		{
			System.out.println("A is =less");
		}
		else if(b<a&& b<c)
		{
			System.out.println("B is less");
			
		}else
		{
			System.out.println("C is less");
		}
	}

}
