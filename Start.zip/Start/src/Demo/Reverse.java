package Demo;
import java.util.*;
public class Reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int r=0;
		 int n=0;
		 int count=0;
		 System.out.println("Enter No :- ");
		 Scanner sc = new  Scanner(System.in); 
		 
		 int y=sc.nextInt();
		 sc.close();
		 
		 do{
			 n=y%10;
		//	 System.out.println(n);
			 r=(r*10)+n;
			 y=y/10;
			count++;
			 }while(y>0);
		 System.out.println(count);
		 
		 
	}

	}
