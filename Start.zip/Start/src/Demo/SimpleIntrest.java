package Demo;

public class SimpleIntrest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        double p=20000;
        int r=12;
        int t =12;
        double SI= (p*t*r)/100;
        System.out.println(SI);
        
	}

}
