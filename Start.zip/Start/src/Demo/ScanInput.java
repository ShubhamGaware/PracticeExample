package Demo;

import java.util.*;

public class ScanInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc =new Scanner(System.in);
		System.out.println("Enter String:-");
		String Name = sc.next();
		System.out.println("Name: "+Name);
		System.out.println("enter Number");
		int no=sc.nextInt();
		System.out.println("number:"+no);
		String Str= Name+no;
		System.out.println(Str);
		sc.close();
			
	}

}
