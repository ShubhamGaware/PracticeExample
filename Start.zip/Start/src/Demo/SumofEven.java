package Demo;

public class SumofEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 int i;
         int sum=0;
         for (i=30;i<=50;i++)
         {
       	  if(i%2==0)
       	  sum=sum+i;
         }
         System.out.println(sum);
	
	}
	
	

}
