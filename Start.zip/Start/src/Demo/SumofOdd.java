package Demo;

public class SumofOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i;
        int sum=0;
        for (i=40;i<=50;i++)
        {
      	  if(i%2==1)
      	  sum=sum+i;
        }
        System.out.println(sum);
	
	}

}
