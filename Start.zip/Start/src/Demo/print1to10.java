package Demo;

public class print1to10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int  i=1;
		while(i<=10)
		{ if(i%2==0)
			System.out.println(i);
			i++;
		}
		
	}

}
