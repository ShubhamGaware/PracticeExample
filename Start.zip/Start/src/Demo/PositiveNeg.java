package Demo;

public class PositiveNeg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int Num= -10;
		if(Num>0) 
		{
	   	 System.out.println("given no is positive..!");
		}
		else
		{
			System.out.println("Given no  is  negative..!");
		}

	}

}
