package Demo;

public class Max {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int y=874;
	int n=0,sum=0;
	while(y>0) {
		n=y%10;
		sum=sum+n;
		y=y/10;
	}
	
	System.out.println(sum);
	}
	
}
