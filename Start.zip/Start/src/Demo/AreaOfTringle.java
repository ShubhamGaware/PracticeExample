package Demo;

public class AreaOfTringle {

	public static void main(String[] args) {
		double h=11.22;
		double w = 22.00;
		double area = (h*w)/2;
		System.out.println(area);
		
				

	}

}
