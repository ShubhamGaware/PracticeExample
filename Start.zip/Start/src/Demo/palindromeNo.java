package Demo;

import java.util.Scanner;

public class palindromeNo {

	public static void main(String[] args) {
int m,a,n,sum=0, sum1=0;
Scanner s =new Scanner(System.in);
m=s.nextInt();
a=s.nextInt();
while (m>0)
{
	n=m%10;
	sum=sum+n;
	m=m/10;
}
while (a>0)
{
	n=a%10;
	sum1=sum1+n;
	a=a/10;
}
System.out.println(sum);
System.out.println(sum1);
	}

}
