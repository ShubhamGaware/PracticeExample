package Demo;

public class logicalOp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 105;
		int y = 102;
		System.out.println((x>y)&&(x<y));
		System.out.println((x<y)&&(x>y));
		System.out.println((x>=y)&&(x<=y));
		System.out.println((x<=y)&&(x>=y));
		System.out.println((x==y)&&(x!=y));
		System.out.println((x==y)&&(x==y));
		System.out.println((x>y)||(x<y));
		System.out.println((x<y)||(x>y));
		System.out.println((x>=y)||(x<=y));
		System.out.println((x<=y)||(x>=y));
		System.out.println((x==y)||(x!=y));
		System.out.println((x==y)||(x==y));
		

	}

}
