package Demo;

public class operationDT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long a = 10000000;
		long b = 12700000;
		long sum, max, mul;
		double div;
		
			sum=a+b;
			max=a-b;
			mul=a*b;
			div=b/a;
			System.out.println(sum);
			System.out.println(max);
			System.out.println(mul);
			System.out.println(div);

	}

}
