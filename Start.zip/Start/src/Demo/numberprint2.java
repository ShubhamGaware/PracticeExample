package Demo;

public class numberprint2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i=30; i>=20;i--)
		  {
			  System.out.println(i);
			  
		  }
	}

}
