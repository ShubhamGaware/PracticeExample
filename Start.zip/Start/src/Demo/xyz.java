package Demo;

public class xyz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int y=8;
		int x=10;
		double z=(y++/3)+ ++x;
		System.out.println(z);

	}

}
