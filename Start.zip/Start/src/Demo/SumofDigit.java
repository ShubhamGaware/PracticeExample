package Demo;

public class SumofDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int Num=4567;
		int Sum=0;
		int n=0;
		while(Num>0)
		{
			n=Num%10;
			Sum=Sum+n;
			n=Num/10;
		}
		System.out.println(Sum);
		
	}

}
