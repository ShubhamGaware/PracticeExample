package Demo;

import java.util.Scanner;

public class PrimeNO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter Number : ");
		Scanner sc  = new Scanner (System.in);
		int  number =sc.nextInt();
		sc.close();
		int i,count=0;
	
		for (i=2;i<number;i++)
			
		{
			if(number%i==0)
			{
				count++;
				break;
			}
		}
		if(count==0)
		System.out.println("it is prime");
		else 
			System.out.println("not prinme");
		
				
	} 

}
