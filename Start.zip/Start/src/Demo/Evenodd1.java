package Demo;
import java.util.*;
public class Evenodd1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number :");
		int num=sc.nextInt();
		sc.close();
		if(num%2==0)
		{
			System.out.println("Given no is even  no..!!");
			
		}else
		{
			System.out.println("Given No is Odd no..!!");
		}
	}
}
