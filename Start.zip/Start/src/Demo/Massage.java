package Demo;

public class Massage {

	public static void main(String[] args) {
		System.out.println("Hello this is world of love");

	}

}
