package Demo;

public class DivbythreeFive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a= 10;
		 if (a%3==0)
		 {
			 System.out.println("given no  is divisible 3");
		 }
		 else if(a%5==0) 
		 {
			 System.out.println("given no is  divisible  by 5");
			 
		 }
		 else {
			 System.out.println("given no is not divisible both..!");
		 }

	}

}
