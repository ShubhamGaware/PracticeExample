package Demo;

public class evenodd2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i=20; i<=40;i++)
		  { if (i%2==0)
		  {
			  System.out.println(i);
			  
		  }
	}
		
	}
} 
