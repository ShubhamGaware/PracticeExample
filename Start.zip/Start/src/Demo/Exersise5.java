package Demo;

public class Exersise5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.out.println("Addition ="+ (30+40));
		 System.out.println("Subraction ="+ (30-40));
		 System.out.println("Multiplication ="+ (60*40));
		 System.out.println("Division ="+ (1000/40));
		 System.out.println("Square ="+ (30*30));
		 

	}

}
