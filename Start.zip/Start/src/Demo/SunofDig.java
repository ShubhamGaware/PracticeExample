package Demo;

public class SunofDig {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int y=12345;
 int sum=0; int n=0;
 do {
	 n=y%10;
	 sum=sum+n;
	 y=y/10; 
 
 
	}while(y>0);
  System.out.println(sum);
	}
	
}
