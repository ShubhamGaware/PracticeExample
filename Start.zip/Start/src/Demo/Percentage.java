package Demo;

public class Percentage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int s1=75;
		int s2=70;
		int s3=80;
		int s4=88;
		int s5=90;
		int total=s1+s2+s3+s4+s5;
		System.out.println(total);
		double percent=total/5;
		System.out.println(percent);
	}

}
