package Demo;

public class operatorexamples {

	public static void main(String[] args) {
		// Relational operator example
		int a= 100;
		int b =200;
		System.out.println(a<b);
		System.out.println(a>b);
		System.out.println(a==b);
		System.out.println(a!=b);
		System.out.println(a<=b);
		System.out.println(a>=b);
		System.out.println(a==b);
		System.out.println(a!=b);
		
		

	}

}
