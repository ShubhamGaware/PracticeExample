package Demo;

public class RestoBill {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Dish1 = "Paneer";
		String Rice="Jeera Rice";
		String Roti="Butter Roti";
		int price_for_Dish1 = 170;
		int price_for_Dish2= 120;
		int price_for_Dish3= 15;
		int quant1 = 4;
		int quant2 = 3;
		int quant3 = 20;
	System.out.println("Dish_name : " + Dish1 + "\nprice Of Dish : "+ price_for_Dish1 + "\nquantity : " +quant1);
	double total_price1 = price_for_Dish1 *  quant1;
	System.out.println("Total price of Dish " + total_price1 );
	System.out.println("Rice_name : " + Rice + "\nprice Of Rice : "+ price_for_Dish2 + "\nquantity : " +quant2);
	double total_price2 =price_for_Dish2 *  quant2;
	System.out.println("Total price of Rice" + total_price2 );
	System.out.println("Roti_name : " + Roti + "\nprice Of  Roti : "+ price_for_Dish3 + "\nquantity : " +quant3);
	double total_price3 = price_for_Dish3 *  quant3;
	System.out.println("Total price of   Roti : " + total_price3 );
	
	double Total_Bill=total_price1+total_price2+total_price3;
	System.out.println("\nTotal Bill of All Meal  :" + Total_Bill);
       
	}

}
