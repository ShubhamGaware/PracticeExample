package Demo;

public class Max1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		int a=600;
		int b=500;
		int c= 400;
		int  Result= ((a>b)&&(a>c))?(a):((b>a)&&(b>c))?(b):(c);
		System.out.println(Result);
	}

}
