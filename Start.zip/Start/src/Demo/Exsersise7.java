package Demo;

public class Exsersise7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=20,b=10;
		System.out.println(a+b);
		System.out.println(a);
		System.out.println(b);
		System.out.println("a");
		System.out.println("b");
		System.out.println("a+b");

	}

}
